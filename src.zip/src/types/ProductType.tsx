type ProductType = {
  id: string;
  title: string;
  price: number;
  quantityChosen: number;
  category_id: string;
  thumbnail: string;
};

export default ProductType;
